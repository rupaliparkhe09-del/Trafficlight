# Smart Traffic Light Controller

- `index.html`: mobile-friendly interactive UI demo.
- `traffic_light_controller.v`: Verilog 3-state finite-state machine.
- `tb_traffic_light_controller.v`: Icarus Verilog testbench.

## Open the UI
Open `index.html` in a mobile browser, or upload it to a static host such as GitHub Pages.

## Run Verilog simulation (requires Icarus Verilog)
```bash
iverilog -o traffic_sim traffic_light_controller.v tb_traffic_light_controller.v
vvp traffic_sim
```

Important: the static webpage runs a JavaScript demonstration of the traffic-light sequence; it does not execute Icarus Verilog in the browser. Use the Verilog files and testbench for actual HDL simulation.
