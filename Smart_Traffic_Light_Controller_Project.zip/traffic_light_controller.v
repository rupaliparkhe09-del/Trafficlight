// Smart Traffic Light Controller: 3-state FSM
module traffic_light_controller(input wire clk, input wire reset, output reg red, output reg yellow, output reg green);
    localparam RED=2'b00, GREEN=2'b01, YELLOW=2'b10;
    reg [1:0] state; reg [3:0] count;
    // Demonstration timer: each state lasts 5 clock ticks.
    always @(posedge clk or posedge reset) begin
        if(reset) begin state<=RED; count<=0; end
        else if(count==4'd4) begin
            count<=0;
            case(state) RED:state<=GREEN; GREEN:state<=YELLOW; YELLOW:state<=RED; default:state<=RED; endcase
        end else count<=count+1'b1;
    end
    always @(*) begin
        red=0; yellow=0; green=0;
        case(state) RED:red=1; GREEN:green=1; YELLOW:yellow=1; default:red=1; endcase
    end
endmodule
