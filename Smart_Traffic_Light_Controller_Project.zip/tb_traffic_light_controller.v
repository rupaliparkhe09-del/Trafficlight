`timescale 1ns/1ps
module tb_traffic_light_controller;
 reg clk=0, reset=1; wire red,yellow,green;
 traffic_light_controller dut(.clk(clk),.reset(reset),.red(red),.yellow(yellow),.green(green));
 always #5 clk=~clk;
 initial begin
   $display("time reset RED YELLOW GREEN");
   $monitor("%4t   %b    %b   %b      %b",$time,reset,red,yellow,green);
   #12 reset=0; #180 $finish;
 end
endmodule
